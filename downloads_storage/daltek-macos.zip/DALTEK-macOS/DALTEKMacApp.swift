import SwiftUI
import WebKit

@main
struct DALTEKMacApp: App {
    var body: some Scene {
        WindowGroup {
            DALTEKMacContentView()
                .frame(minWidth: 1024, minHeight: 700)
        }
        .windowStyle(HiddenTitleBarWindowStyle())
    }
}

struct DALTEKMacContentView: NSViewRepresentable {
    func makeNSView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        let webView = WKWebView(frame: .zero, configuration: config)
        if let url = URL(string: "https://ais-pre-h57hoexwhutai4uvntr75c-246438389907.europe-west2.run.app") {
            webView.load(URLRequest(url: url))
        }
        return webView
    }

    func updateNSView(_ nsView: WKWebView, context: Context) {}
}
