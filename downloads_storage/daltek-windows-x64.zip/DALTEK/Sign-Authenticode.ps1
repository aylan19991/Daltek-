# DALTEK Authenticode Signature Script
param (
    [string]$CertificatePath = "daltek_code_sign.pfx",
    [string]$Password = ""
)

$targetExe = "bin\Release\net8.0-windows10.0.19041.0\DALTEK.exe"
if (-not (Test-Path $targetExe)) {
    Write-Error "Fichier exécutable introuvable : $targetExe. Veuillez d'abord compiler le projet en mode Release."
    exit 1
}

Write-Host "Signature Authenticode de DALTEK.exe avec horodatage RFC 3161..."
signtool.exe sign /f $CertificatePath /p $Password /fd SHA256 /tr http://timestamp.digicert.com /td SHA256 /d "DALTEK Queue Management" $targetExe

Write-Host "Vérification de la signature..."
signtool.exe verify /pa /v $targetExe
Write-Host "Signature Authenticode réussie avec succès !"
