using System;
using System.Windows;
using Microsoft.Web.WebView2.Core;

namespace DALTEK
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            InitializeAsync();
        }

        async void InitializeAsync()
        {
            await MainWebView.EnsureCoreWebView2Async(null);
            MainWebView.CoreWebView2.Settings.IsStatusBarEnabled = false;
        }
    }
}
