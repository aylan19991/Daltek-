using System.Windows;

namespace DALTEK
{
    public partial class App : Application
    {
    }
}
