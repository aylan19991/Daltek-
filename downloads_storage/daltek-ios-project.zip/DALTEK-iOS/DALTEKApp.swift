import SwiftUI
import WebKit

@main
struct DALTEKApp: App {
    var body: some Scene {
        WindowGroup {
            DALTEKContentView()
                .ignoresSafeArea()
        }
    }
}

struct DALTEKContentView: UIViewRepresentable {
    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        let webView = WKWebView(frame: .zero, configuration: config)
        if let url = URL(string: "https://ais-pre-h57hoexwhutai4uvntr75c-246438389907.europe-west2.run.app") {
            let request = URLRequest(url: url)
            webView.load(request)
        }
        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}
}
